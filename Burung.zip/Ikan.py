class Ikan:
    def __init__(self, nama, makanan, hidup, berkembang_biak):
        self.nama = nama
        self.makanan = makanan
        self.hidup = hidup
        self.berkembang_biak = berkembang_biak
    def cetak(self):
        print("\nNama \t\t: ", self.nama,
              "\nMakanan \t\t: ", self.makanan,
              "\nHidup \t\t: ", self.hidup,
              "\nBerkembang biak \t\t: ", self.berkembang_biak
              )

arwana = Ikan("Arwana", "Pelet, Ikan Kecil, Cacing", "Air Tawar", "Bertelur")
arwana.cetak()

siam = Ikan("Siam", "Pelet, Ikan Kecil, Cacing", "Air Tawar", "Bertelur")
siam.cetak()
