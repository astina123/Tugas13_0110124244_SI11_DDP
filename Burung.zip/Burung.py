from Ikan import *

class Burung(Ikan): 
    def __init__(self, nama, makanan, hidup, berkembang_biak, jenis, bunyi,):
        super().__init__(nama, makanan, hidup, berkembang_biak)
        self.jenis = jenis
        self.bunyi = bunyi
    def cetak_burung(self):
        return super().cetak()
        print("Jenis\tt: ", self.jenis,
        "\nBunyi \tt : ", self.bunyi)

    def __init__(self, nama, makanan, hidup, berkembang_biak, jenis, bunyi,):
        super().__init__(nama, makanan, hidup, berkembang_biak)
        self.jenis = jenis
        self.bunyi = bunyi
    def cetak_burung(self):
        return super().cetak()
        print("Jenis\tt: ", self.jenis,
        "\nBunyi \tt : ", self.bunyi)


merpati = Burung("Merpati", "Biji", "Pohon", "Bertelur", "merpati", "Kruk Kruk")
merpati.cetak_burung()


kakatua = Burung("kakatua", "Biji", "Pohon", "Bertelur", "Kakatua", "Kruk Kruk")
kakatua.cetak_burung()